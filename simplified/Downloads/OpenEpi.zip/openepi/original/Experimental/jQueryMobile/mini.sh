nodefront minify -p modules.js
mv modules.min.js modules.jade